import pygame, os

class ElementGraphique():
    def __init__(self, img, fen, x,y):
        self.image = img
        self.rect = img.get_rect()
        self.fenetre = fen
        self.rect.x = x
        self.rect.y = y

    def afficher(self):
        self.fenetre.blit(self.image, self.rect)

    

    def collide(self,other):
        if self.rect.colliderect(other.rect):
            return True
        return False

class Perso(ElementGraphique):
    def __init__(self, img, fen, x,y):
        ElementGraphique.__init__(self, img, fen, x,y)
        
    def deplacer(self):
        largeur, hauteur = fenetre.get_size()

        if (touches[pygame.K_LEFT]):
            self.rect.x -= 5
        if (touches[pygame.K_RIGHT]):
            self.rect.x += 5
        if (touches[pygame.K_UP]):
            self.rect.y -= 5
        if (touches[pygame.K_DOWN]):
            self.rect.y += 5
        
        if (self.rect.x < 0):
            self.rect.x = 0
        if (self.rect.x + self.rect.w > largeur):
            self.rect.x = largeur - self.rect.w
        if (self.rect.y < 0):
            self.rect.y = 0
        if (self.rect.y + self.rect.h > hauteur):
            self.rect.y = hauteur - self.rect.h

class Balle(ElementGraphique):
    def __init__(self, img, fen, x,y, dx, dy):
        ElementGraphique.__init__(self, img, fen, x,y)
        self.dx = dx
        self.dy = dy
    def deplacer(self):
        self.rect.x += self.dx
        self.rect.y += self.dy
        largeur, hauteur = self.fenetre.get_size()
        if (self.rect.y < 0 or self.rect.y + self.rect.h > hauteur) :
            self.dy = -self.dy
        if (self.rect.x < 0 or self.rect.x + self.rect.w > largeur):
            self.dx = -self.dx

def afficher_obj(objects, other):
    # objects = []
    for obj in objects :
        # objects.append(object)
        fenetre.blit(obj.image, obj.rect)
        obj.deplacer()
        if other.collide(obj):
            obj.image = pygame.transform.scale(pygame.image.load(os.path.join('ball_states', 'ball3.png')), DEFAULT_IMAGE_SIZE)
            

# Initialisation de la bibliotheque pygame
pygame.init()

#creation de la fenetre
largeur = 640
hauteur = 480
fenetre=pygame.display.set_mode((largeur,hauteur))


# lecture de l'image du perso
imagePerso = pygame.image.load("perso.png")

perso = Perso(imagePerso,fenetre,60,80)


# lecture de l'image du fond
imageFond = pygame.image.load("background.png").convert()
fond = ElementGraphique(imageFond,fenetre,0,0)

## Ajoutons un texte fixe dans la fenetre :
# Choix de la police pour le texte
font = pygame.font.Font(None, 34)
score = 1000
# Creation de l'image correspondant au texte
imageText = font.render('<Escape> pour quitter : '+str(score), True, (255, 0, 255))

# creation d'un rectangle pour positioner l'image du texte
texte = ElementGraphique(imageText,fenetre,10,10)
DEFAULT_IMAGE_SIZE = (40, 40)
imageBalle = pygame.transform.scale(pygame.image.load(os.path.join('ball_states', 'ball1.png')), DEFAULT_IMAGE_SIZE)
imageBall1 = pygame.transform.scale(pygame.image.load(os.path.join('ball_states', 'ball3.png')), DEFAULT_IMAGE_SIZE)

balle = Balle(imageBalle,fenetre,200,200, 3, 3)
ball1 = Balle(imageBall1,fenetre,160,100, 3, 4)
ball2 = Balle(imageBalle,fenetre,200,210, 5, 3)
ball3 = Balle(imageBalle,fenetre,300,230, -3, 6)
balls = [ball1, ball2, ball3]

# servira a regler l'horloge du jeu
horloge = pygame.time.Clock()

# la boucle dont on veut sortir :
#   - en appuyant sur ESCAPE
#   - en cliquant sur le bouton de fermeture
i=1;
continuer=1
while continuer:

    # fixons le nombre max de frames / secondes
    horloge.tick(30)

    i=i+1
    print (i)

    # on recupere l'etat du clavier
    touches = pygame.key.get_pressed();

    # si la touche ESC est enfoncee, on sortira
    # au debut du prochain tour de boucle
    if touches[pygame.K_ESCAPE] :
        continuer=0

    
    balle.deplacer()
    perso.deplacer()
    # Gestion des collisions
    if perso.collide(balle):
        continuer=0


    # Affichage du fond
    fond.afficher()

    # Affichage Perso
    perso.afficher()

    balle.afficher()
    afficher_obj(balls, perso)
    # Affichage du Texte
    texte.afficher()

    # rafraichissement
    pygame.display.flip()

    # Si on a clique sur le bouton de fermeture on sortira
    # au debut du prochain tour de boucle
    # Pour cela, on parcours la liste des evenements
    # et on cherche un QUIT...
    for event in pygame.event.get():   # parcours de la liste des evenements recus
        if event.type == pygame.QUIT:     #Si un de ces evenements est de type QUIT
            continuer = 0	   # On arrete la boucle

# fin du programme principal...
pygame.quit()
